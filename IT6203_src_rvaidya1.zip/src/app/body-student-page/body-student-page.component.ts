import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-body-student-page',
  templateUrl: './body-student-page.component.html',
  styleUrls: ['./body-student-page.component.css']
})
export class BodyStudentPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
