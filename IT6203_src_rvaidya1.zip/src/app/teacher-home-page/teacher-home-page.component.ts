import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teacher-home-page',
  templateUrl: './teacher-home-page.component.html',
  styleUrls: ['./teacher-home-page.component.css']
})
export class TeacherHomePageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
